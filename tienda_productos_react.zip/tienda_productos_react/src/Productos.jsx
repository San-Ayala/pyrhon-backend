
import { useState } from "react"

function Productos() {
    const [productos, setProductos] = useState([])
    const [codigo, setCodigo] = useState("")
    const [nombre, setNombre] = useState("")
    const [precio, setPrecio] = useState("")
    const [categoria, setCategoria] = useState("")
    const [idBuscar, setIdBuscar] = useState("")
    const [productoEncontrado, setProductoEncontrado] = useState(null)

    // Consultar todos los productos
    async function consultarProductos() {
        let respuesta = await fetch("http://127.0.0.1:5000/api/v1/productos")
        let datos = await respuesta.json()

        setProductos(datos.Productos)
    }

    // Registrar un producto
    async function guardarProducto() {
        if (codigo === "" || nombre === "" || precio === "" || categoria === "") {
            alert("Complete todos los campos")
            return
        }

        let respuesta = await fetch("http://127.0.0.1:5000/api/v1/productos", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                proCodigo: codigo,
                proNombre: nombre,
                proPrecio: Number(precio),
                proCategoria: categoria
            })
        })

        let datos = await respuesta.json()
        alert(datos.mensaje)

        if (respuesta.ok) {
            setCodigo("")
            setNombre("")
            setPrecio("")
            setCategoria("")
            consultarProductos()
        }
    }

    // Buscar producto por ID
    async function buscarProducto() {
        if (idBuscar === "") {
            alert("Ingrese el ID del producto")
            return
        }

        let respuesta = await fetch("http://127.0.0.1:5000/api/v1/productos/" + idBuscar)
        let datos = await respuesta.json()

        if (respuesta.ok) {
            setProductoEncontrado(datos.Producto)
        } else {
            alert(datos.mensaje)
            setProductoEncontrado(null)
        }
    }

    // Actualizar un producto
    async function actualizarProducto() {
        if (idBuscar === "") {
            alert("Ingrese el ID del producto")
            return
        }

        if (codigo === "" || nombre === "" || precio === "" || categoria === "") {
            alert("Complete los datos del producto")
            return
        }

        let respuesta = await fetch("http://127.0.0.1:5000/api/v1/productos/" + idBuscar, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                proCodigo: codigo,
                proNombre: nombre,
                proPrecio: Number(precio),
                proCategoria: categoria
            })
        })

        let datos = await respuesta.json()
        alert(datos.mensaje)

        if (respuesta.ok) {
            consultarProductos()
            setProductoEncontrado(datos.Producto)
        }
    }

    // Eliminar un producto
    async function eliminarProducto() {
        if (idBuscar === "") {
            alert("Ingrese el ID del producto")
            return
        }

        let respuesta = await fetch("http://127.0.0.1:5000/api/v1/productos/" + idBuscar, {
            method: "DELETE"
        })

        let datos = await respuesta.json()
        alert(datos.mensaje)

        if (respuesta.ok) {
            setIdBuscar("")
            setProductoEncontrado(null)
            consultarProductos()
        }
    }

    return (
        <div>
            <h1>Inventario de Productos</h1>

            <h2>Registrar producto</h2>

            <input
                type="text"
                placeholder="Código del producto"
                value={codigo}
                onChange={(e) => setCodigo(e.target.value)}
            />

            <input
                type="text"
                placeholder="Nombre del producto"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
            />

            <input
                type="number"
                placeholder="Precio"
                value={precio}
                onChange={(e) => setPrecio(e.target.value)}
            />

            <input
                type="text"
                placeholder="Categoría"
                value={categoria}
                onChange={(e) => setCategoria(e.target.value)}
            />

            <button onClick={guardarProducto}>
                Guardar producto
            </button>

            <h2>Buscar, actualizar y eliminar producto</h2>

            <input
                type="number"
                placeholder="Ingrese el ID"
                value={idBuscar}
                onChange={(e) => setIdBuscar(e.target.value)}
            />

            <button onClick={buscarProducto}>
                Buscar producto
            </button>

            <button onClick={actualizarProducto}>
                Actualizar producto
            </button>

            <button onClick={eliminarProducto}>
                Eliminar producto
            </button>

            {productoEncontrado && (
                <div>
                    <h3>Producto encontrado</h3>
                    <p>ID: {productoEncontrado.idProducto}</p>
                    <p>Código: {productoEncontrado.proCodigo}</p>
                    <p>Nombre: {productoEncontrado.proNombre}</p>
                    <p>Precio: {productoEncontrado.proPrecio}</p>
                    <p>Categoría: {productoEncontrado.proCategoria}</p>
                </div>
            )}

            <h2>Lista de productos</h2>

            <button onClick={consultarProductos}>
                Mostrar productos
            </button>

            <table border="1">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Código</th>
                        <th>Nombre</th>
                        <th>Precio</th>
                        <th>Categoría</th>
                    </tr>
                </thead>

                <tbody>
                    {productos.map((producto) => (
                        <tr key={producto.idProducto}>
                            <td>{producto.idProducto}</td>
                            <td>{producto.proCodigo}</td>
                            <td>{producto.proNombre}</td>
                            <td>{producto.proPrecio}</td>
                            <td>{producto.proCategoria}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    )
}

export default Productos
