
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from config import *

# Se crea la aplicacion Flask
api = Flask(__name__)

# Permite la conexion con React
cors = CORS(api)

# Cadena de conexion con MySQL
cadenaConexion = f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

api.config["SQLALCHEMY_DATABASE_URI"] = cadenaConexion

# Se crea el objeto de la base de datos
db = SQLAlchemy(api)

# Importamos las rutas
from routes.routes import *

if __name__ == "__main__":
    with api.app_context():
        db.create_all()

    api.run(port=5000, debug=True)