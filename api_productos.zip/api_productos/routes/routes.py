
from flask import request, jsonify
from app import api, db
from models.producto import Producto
from sqlalchemy import exc


# Registrar producto
@api.route("/api/v1/productos", methods=["POST"])
def crearProducto():
    try:
        datos = request.get_json()

        if not datos:
            return jsonify({"mensaje": "Debe enviar datos JSON"}), 400

        producto = Producto(
            proCodigo=datos["proCodigo"],
            proNombre=datos["proNombre"],
            proPrecio=datos["proPrecio"],
            proCategoria=datos["proCategoria"]
        )

        db.session.add(producto)
        db.session.commit()

        return jsonify({
            "mensaje": "Producto agregado correctamente",
            "Producto": producto.to_dict()
        }), 201

    except (KeyError, TypeError, ValueError):
        return jsonify({"mensaje": "Datos incompletos o incorrectos"}), 400

    except exc.IntegrityError:
        db.session.rollback()
        return jsonify({"mensaje": "El codigo del producto ya existe"}), 409

    except exc.SQLAlchemyError:
        db.session.rollback()
        return jsonify({"mensaje": "Error en la base de datos"}), 500


# Obtener todos los productos
@api.route("/api/v1/productos", methods=["GET"])
def obtenerProductos():
    productos = Producto.query.all()
    listaProductos = []

    for p in productos:
        listaProductos.append(p.to_dict())

    return jsonify({
        "mensaje": "Productos",
        "Productos": listaProductos
    }), 200


# Obtener producto por ID
@api.route("/api/v1/productos/<int:idProducto>", methods=["GET"])
def obtenerProductoPorID(idProducto):
    producto = db.session.get(Producto, idProducto)

    if producto is None:
        return jsonify({"mensaje": "No existe producto con ese ID"}), 404

    return jsonify({
        "mensaje": "Producto encontrado",
        "Producto": producto.to_dict()
    }), 200


# Actualizar producto
@api.route("/api/v1/productos/<int:idProducto>", methods=["PUT"])
def actualizarProducto(idProducto):
    producto = db.session.get(Producto, idProducto)

    if producto is None:
        return jsonify({"mensaje": "No existe producto con ese ID"}), 404

    try:
        datos = request.get_json()

        producto.proCodigo = datos["proCodigo"]
        producto.proNombre = datos["proNombre"]
        producto.proPrecio = datos["proPrecio"]
        producto.proCategoria = datos["proCategoria"]

        db.session.commit()

        return jsonify({
            "mensaje": "Producto actualizado",
            "Producto": producto.to_dict()
        }), 200

    except (KeyError, TypeError, ValueError):
        db.session.rollback()
        return jsonify({"mensaje": "Datos incompletos o incorrectos"}), 400

    except exc.IntegrityError:
        db.session.rollback()
        return jsonify({"mensaje": "El codigo ya existe"}), 409

    except exc.SQLAlchemyError:
        db.session.rollback()
        return jsonify({"mensaje": "Error en la base de datos"}), 500


# Eliminar producto
@api.route("/api/v1/productos/<int:idProducto>", methods=["DELETE"])
def eliminarProducto(idProducto):
    producto = db.session.get(Producto, idProducto)

    if producto is None:
        return jsonify({"mensaje": "No existe producto con ese ID"}), 404

    try:
        db.session.delete(producto)
        db.session.commit()

        return jsonify({"mensaje": "Producto eliminado"}), 200

    except exc.SQLAlchemyError:
        db.session.rollback()
        return jsonify({"mensaje": "Error al eliminar producto"}), 500
